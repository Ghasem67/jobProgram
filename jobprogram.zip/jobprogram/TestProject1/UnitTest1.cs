using NUnit.Framework;
using System;
using System.Collections.Generic;
using WebApplication1.Controllers;
using WebApplication1.Models;

namespace TestProject1
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            HomeController homeController = new HomeController();
            List<ProgramDTO> s = homeController.GetJobProgram(DateTime.Now.ToString(), 7);
           Assert.
            Assert.Pass();
        }
    }
}