﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class ProgramDTO
    {
        public DateTime StartJob { get; set; }
        public DateTime EndJob { get; set; }
        public string DayName { get; set; }
    }
}
